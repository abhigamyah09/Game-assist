# GameAssist — Accessibility Helper

An Android accessibility app that helps **visually impaired and differently-abled gamers** enjoy mobile games independently. GameAssist captures the screen, detects falling threats (meteors/fireballs), satellites/UFOs, and collectibles, then **gently guides the player character** out of harm's way by simulating human-like drag gestures via the Android AccessibilityService.

> **Target:** Android 8.0 (API 26) and above
> **Language:** Kotlin
> **Min SDK:** 26 · **Target SDK:** 34 · **Compile SDK:** 34

---

## Why this exists

Many casual mobile games — endless runners, meteor-dodgers, satellite-avoiders — demand fast, precise finger drags that are simply impossible for players with motor disabilities. GameAssist levels the playing field: the player just turns the assist on, and the app plays *for* them at human-like speed.

The app is **assistive technology**, not a cheating tool — movement is intentionally bounded to ~25% of the screen width per second (no teleports) so it behaves like a careful human co-pilot rather than a bot.

---

## Features

| Area | Implementation |
|---|---|
| **Visual detection** | Pixel-sampling color detector over a downscaled bitmap; HSV-space classification for red/orange meteors, blue satellites, and white/silver collectibles. |
| **Auto-calibration** | Samples dominant colors for the first 3 seconds, then raises detection thresholds if the game background is itself red/blue/white (e.g. lava levels, sky levels, snow levels). |
| **Smart movement** | `ThreatAnalyzer` decides where to go: threat-left → move right; threat-right → move left; threat-center → flee to farthest edge; collectible → grab it; satellite trajectory predicted by linear extrapolation over the last 4 frames. |
| **Gesture control** | `AccessibilityService.dispatchGesture` injects smooth drag paths with many waypoints; reaction time 100–200 ms; min interval 120 ms; tiny sine wobble on Y so the path doesn't look like a robotic straight line. |
| **Floating overlay** | Draggable FAB + status pill (`Scanning / Safe / Threat ← / Threat → / Threat ↑ / Collectible nearby / Calibrating`). Color-coded, screen-reader friendly. |
| **Accessibility UI** | Works on top of any app. TalkBack announcements for state changes. Optional vibration on every injected gesture. |
| **Built-in demo game** | `MeteorDodgeActivity` — a minimal meteor-dodge mini-game with the exact visual palette GameAssist expects, so you can verify the assist works end-to-end without installing a third-party game. |

---

## Project structure

```
GameAssist/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/gameassist/accessibility/
│       │   │   ├── GameAssistApp.kt
│       │   │   ├── demo/MeteorDodgeActivity.kt        ← built-in test game
│       │   │   ├── overlay/OverlayManager.kt          ← FAB + status pill
│       │   │   ├── service/
│       │   │   │   ├── GameAssistService.kt           ← AccessibilityService
│       │   │   │   ├── ScreenCaptureManager.kt        ← MediaProjection
│       │   │   │   ├── ColorDetector.kt               ← pixel-sampling
│       │   │   │   ├── AutoCalibrator.kt              ← self-tuning
│       │   │   │   ├── ThreatAnalyzer.kt              ← decision engine
│       │   │   │   ├── GestureEngine.kt               ← dispatchGesture
│       │   │   │   ├── PlayerTracker.kt               ← EMA smoothing
│       │   │   │   └── Geometry.kt                    ← data models
│       │   │   ├── ui/{MainActivity,SettingsActivity}.kt
│       │   │   └── util/{ColorUtils,GameAssistPrefs}.kt
│       │   └── res/
│       │       ├── drawable/, layout/, mipmap-*/ values/, xml/
│       └── test/java/com/gameassist/accessibility/
│           ├── ColorUtilsTest.kt
│           ├── ColorDetectorTest.kt
│           ├── ThreatAnalyzerTest.kt
│           ├── AutoCalibratorTest.kt
│           ├── PlayerTrackerTest.kt
│           └── GestureEnginePlanTest.kt
└── README.md (this file)
```

---

## How to build

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK 34

### Build from Android Studio
1. **File → Open** and select the `GameAssist/` directory.
2. Wait for Gradle sync to complete.
3. Plug in an Android 8.0+ device (a real device is strongly recommended — emulators' MediaProjection is buggy).
4. **Run ▶** — Android Studio will install and launch the app.

### Build from command line
```bash
cd GameAssist
# Linux / macOS
./gradlew assembleDebug
# Windows
gradlew.bat assembleDebug
```
The debug APK lands at `app/build/outputs/apk/debug/app-debug.apk`.

> **Note:** The Gradle wrapper jar (`gradle/wrapper/gradle-wrapper.jar`) is intentionally not checked in. Either run `gradle wrapper` once with a system Gradle 8.x to generate it, or open the project in Android Studio which will auto-bootstrap the wrapper.

---

## How to use

### One-time setup (3 permissions)
1. Open GameAssist.
2. **Step 1 — Accessibility permission.** Tap *Open Accessibility Settings*, find *GameAssist — Accessibility Helper*, toggle it on, confirm.
3. **Step 2 — Display over other apps.** Tap *Open Overlay Settings*, toggle on.
4. **Step 3 — Screen capture.** Tap *Start Screen Capture*, accept the system dialog. This promotes the service to foreground and starts frame capture.

The status chips at the top of the main screen will all turn green once everything is granted.

### Playing a game with assist
1. Launch the game you want to play (or tap *Launch Demo Game* to try the built-in meteor-dodger).
2. Find the floating blue FAB. Tap it once — it turns bright blue and the status pill shows *Calibrating…* for ~3 seconds.
3. After calibration the status pill switches to *Safe*, *Threat ←*, *Threat →*, *Threat ↑*, or *Collectible nearby* depending on what's on screen.
4. GameAssist will now drag your player out of harm's way. You can release the phone and watch — or keep one finger on the FAB so you can pause the assist by tapping it again (FAB turns grey).

### Settings
Tap *Settings* from the main screen to tune:
- **Player move speed** — max fraction of screen width per second (default 0.25 = 25%, "human-like").
- **Reaction time (ms)** — delay between detection and gesture (default 150 ms).
- **Calibration duration (sec)** — how long to sample dominant colors at startup (default 3 s).
- **Min gesture interval (ms)** — minimum gap between two injections, prevents jitter (default 120 ms).
- **Vibrate on assist action** — haptic feedback whenever a drag is injected.
- **Announce state via TalkBack** — speaks status changes for blind users.

---

## How it works

### Detection pipeline (per frame, ~10 fps)

```
MediaProjection → ImageReader → Bitmap (≤1080px wide)
                                       │
                                       ▼
                         ┌───────────────────────────┐
                         │ AutoCalibrator            │ ← first 3 sec only
                         │  (samples dominant colors │
                         │   adjusts HSV thresholds) │
                         └───────────────────────────┘
                                       │
                                       ▼
                         ┌───────────────────────────┐
                         │ ColorDetector             │
                         │  walk every 4th pixel     │
                         │  bucket into 3×3 grid     │
                         │  emit Blob per non-empty  │
                         └───────────────────────────┘
                                       │
                                       ▼
                         ┌───────────────────────────┐
                         │ PlayerTracker (EMA)       │
                         │  smooth player X / Y      │
                         └───────────────────────────┘
                                       │
                                       ▼
                         ┌───────────────────────────┐
                         │ ThreatAnalyzer            │
                         │  pick action per spec:    │
                         │  L→R, R→L, C→edge,        │
                         │  satellite trajectory,    │
                         │  safe collectible grab    │
                         └───────────────────────────┘
                                       │
                                       ▼
                         ┌───────────────────────────┐
                         │ GestureEngine             │
                         │  plan path (capped speed) │
                         │  dispatchGesture          │
                         │  vibrate + announce       │
                         └───────────────────────────┘
```

### Why HSV instead of RGB
Mobile game frames are full of JPEG compression artifacts, motion blur, and anti-aliasing fringes. RGB thresholds break under these conditions; HSV separates *hue* (which color) from *saturation* (how pure) and *value* (how bright), so a meteor is still recognized as red even when compression has shifted its R channel by ±20.

### Why pixel sampling instead of color-blob tracking
The AndroidX Color histogram API and OpenCV both give more accurate results — but they cost 2–10× more CPU. Pixel sampling at every 4th pixel on a 1080-wide bitmap examines ~1/16 of the pixels and finishes in 30–50 ms on a modern phone, well inside the 100–200 ms reaction budget. The 3×3 spatial grid then clusters adjacent hits into blobs without paying for full connected-components analysis.

### Why linear extrapolation for satellites
The spec says satellites move *diagonally*. We track each satellite across the last 4 frames, match by nearest-center, fit a least-squares line, and predict 2 frames ahead. Full Kalman filtering is overkill for a casual mobile game and would add ~5 KB of state per tracked object.

### Safety constraints (per user spec)
- **Human-like speed** — player moves at most `pref_speed` (default 25%) of screen width per second. No teleports. The drag duration is computed as `movePx / (speed × screenWidth)`, clamped to [120, 1200] ms.
- **Min interval** — `pref_min_interval` (default 120 ms) prevents the assist from issuing two gestures within the same frame.
- **Reaction delay** — `pref_reaction` (default 150 ms) sits between detection and injection, matching the spec's 100–200 ms window.
- **Wobble** — a small sine overshoot (≤1.5% of move distance) on Y makes the drag path look hand-drawn, not robotic.

---

## Testing

The project ships with five unit test classes under `app/src/test/`:

| Test class | What it covers |
|---|---|
| `ColorUtilsTest` | HSV-space color classification: red/orange, blue, white/silver, RGB distance, closeness. |
| `ColorDetectorTest` | Robolectric tests that build solid-color bitmaps and assert the detector finds the right blobs. |
| `ThreatAnalyzerTest` | All five decision rules from the spec: L→R, R→L, C→edge, collectible grab, satellite avoidance, idle, hold, threat-overrides-collectible. |
| `AutoCalibratorTest` | Calibration completion counter, threshold-raising on red/blue/white backgrounds, threshold preservation on neutral backgrounds, reset. |
| `PlayerTrackerTest` | EMA smoothing math, missing-frame retention, reset, glitch detection. |
| `GestureEnginePlanTest` | Pure planning: min/max duration clamps, waypoint count, monotonic speed-vs-duration relationship. |

Run them with:
```bash
./gradlew testDebugUnitTest
```

---

## Compatibility

| Game genre | Expected behavior |
|---|---|
| **Meteor / fireball dodgers** (the demo's genre) | Excellent — designed-for case. |
| **Satellite / UFO avoiders** | Good — trajectory prediction kicks in. |
| **Endless runners with collectibles** | Good — collectible grab logic activates when no imminent threat. |
| **Tap-to-jump platformers** | Not supported — GameAssist only does drags, not taps. |
| **3D / camera-rotating games** | Poor — pixel-sampling assumes a roughly-static camera. |
| **Games with anti-screenshot DRM** (e.g. some banking apps) | Will not work — the captured frames come back black. |

---

## Privacy

GameAssist **never** uploads anything. All detection happens locally on the device. The screen-capture frames are kept in memory only as long as needed to run one detection pass and then recycled.

The `SYSTEM_ALERT_WINDOW` permission is required only to draw the floating FAB. The `BIND_ACCESSIBILITY_SERVICE` permission is required only to call `dispatchGesture`. The `FOREGROUND_SERVICE_MEDIA_PROJECTION` permission is required only to keep the screen-capture loop alive while you're in another app.

---

## Troubleshooting

**The FAB is visible but the assist doesn't move my player.**
Most likely the screen capture hasn't started. Go back to GameAssist's main screen, tap *Start Screen Capture*, then return to your game and tap the FAB.

**The status pill is stuck on *Calibrating…* forever.**
This happens if the first 3 seconds of capture saw only a black screen (rare — usually means MediaProjection returned black frames). Tap the FAB off and on again to restart calibration.

**The assist sometimes moves my player the wrong way.**
Run the built-in demo game first — if it works there but not in your game, the issue is your game's color palette. Open *Settings* and bump *Calibration duration* up to 5 seconds, then toggle the FAB off and on.

**Battery drain is high.**
The detection loop runs at 10 fps regardless of game speed. If you're playing for hours, consider lowering *Player move speed* — slower gestures mean fewer dispatches per minute, which means lower CPU.

---

## License

Released under the MIT License. See source files for copyright header.

GameAssist is provided as-is, without warranty. It is assistive technology, not a guarantee of game progress.
