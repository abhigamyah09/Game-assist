package com.gameassist.accessibility.service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.WindowManager
import java.nio.ByteBuffer

class ScreenCaptureManager(private val context: Context) {
    @Volatile var latestBitmap: Bitmap? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var thread: HandlerThread? = null
    var isRunning = false; private set

    fun start(resultCode: Int, data: Intent) {
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
        val w = (metrics.widthPixels / 2).coerceAtLeast(360)
        val h = (metrics.heightPixels / 2).coerceAtLeast(640)
        imageReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        thread = HandlerThread("CaptureThread").apply { start() }
        imageReader?.setOnImageAvailableListener({ reader ->
            val img = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = img.planes[0]
                val buf: ByteBuffer = plane.buffer
                val rowPad = plane.rowStride - plane.pixelStride * img.width
                val raw = Bitmap.createBitmap(img.width + rowPad / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                buf.rewind(); raw.copyPixelsFromBuffer(buf)
                val cropped = if (raw.width == img.width) raw else Bitmap.createBitmap(raw, 0, 0, img.width, img.height)
                val prev = latestBitmap; latestBitmap = cropped
                if (cropped !== raw) raw.recycle(); prev?.recycle()
            } finally { img.close() }
        }, Handler(thread!!.looper))
        virtualDisplay = projection?.createVirtualDisplay("GameAssist", w, h, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader?.surface, null, null)
        isRunning = true
    }

    fun stop() {
        isRunning = false
        virtualDisplay?.release(); imageReader?.close(); projection?.stop(); thread?.quitSafely()
        latestBitmap?.recycle(); latestBitmap = null
    }
}
