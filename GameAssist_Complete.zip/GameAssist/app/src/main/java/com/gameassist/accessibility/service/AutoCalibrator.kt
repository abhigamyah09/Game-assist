package com.gameassist.accessibility.service
import android.graphics.Bitmap

class AutoCalibrator(private val durationSec: Int) {
    var calibrated = false; private set
    private var frames = 0
    private val targetFrames get() = durationSec * 10
    fun feed(bmp: Bitmap) { if (!calibrated) { frames++; if (frames >= targetFrames) calibrated = true } }
    fun reset() { calibrated = false; frames = 0 }
}
