package com.gameassist.accessibility.service
import com.gameassist.accessibility.AssistAction
import com.gameassist.accessibility.Blob
import com.gameassist.accessibility.ThreatZone

class ThreatAnalyzer(private val screenW: Int, private val screenH: Int) {
    fun analyze(playerX: Float, blobs: ColorDetector.FrameBlobs): AssistAction {
        val margin = screenW * 0.10f
        val dangerY = screenH * 0.55f
        val meteors = blobs.meteors.filter { it.centerY > dangerY }
        val ufos = blobs.ufos.filter { it.centerY > dangerY }
        val threats = meteors + ufos
        val leftThreats = threats.filter { it.zone == ThreatZone.LEFT }
        val rightThreats = threats.filter { it.zone == ThreatZone.RIGHT }
        val centerThreats = threats.filter { it.zone == ThreatZone.CENTER }

        if (centerThreats.isNotEmpty()) {
            val target = if (leftThreats.size <= rightThreats.size) margin else screenW - margin
            return AssistAction(target, screenH * 0.85f, 0.9f, "Center threat")
        }
        if (leftThreats.isNotEmpty() && rightThreats.isEmpty())
            return AssistAction(screenW - margin, screenH * 0.85f, 0.8f, "Left threat")
        if (rightThreats.isNotEmpty() && leftThreats.isEmpty())
            return AssistAction(margin, screenH * 0.85f, 0.8f, "Right threat")

        val safe = blobs.collectibles.firstOrNull { col ->
            col.centerY > screenH * 0.4f && threats.none { t ->
                kotlin.math.abs(t.centerX - col.centerX) < screenW / 4f
            }
        }
        if (safe != null)
            return AssistAction(safe.centerX.coerceIn(margin, screenW - margin), screenH * 0.85f, 0.4f, "Collectible")

        return AssistAction(playerX, screenH * 0.85f, 0f, "Safe")
    }
}
