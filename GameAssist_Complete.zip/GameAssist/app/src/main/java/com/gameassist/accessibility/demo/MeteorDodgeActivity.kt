package com.gameassist.accessibility.demo
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gameassist.accessibility.R

class MeteorDodgeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Simple demo placeholder
        Toast.makeText(this, "Demo Game - Toggle GameAssist ON to test!", Toast.LENGTH_LONG).show()
        finish()
    }
}
