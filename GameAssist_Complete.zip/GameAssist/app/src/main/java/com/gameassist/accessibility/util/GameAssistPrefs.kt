package com.gameassist.accessibility.util

import android.content.Context
import androidx.preference.PreferenceManager

class GameAssistPrefs(context: Context) {
    private val prefs = PreferenceManager.getDefaultSharedPreferences(context)
    val speedFraction: Float get() = prefs.getFloat("pref_speed", 0.25f)
    val reactionMs: Long get() = prefs.getLong("pref_reaction", 150L)
    val calibDurationSec: Int get() = prefs.getInt("pref_calib_duration", 3)
    val minIntervalMs: Long get() = prefs.getLong("pref_min_interval", 120L)
    val vibrate: Boolean get() = prefs.getBoolean("pref_vibrate", true)
    val talkback: Boolean get() = prefs.getBoolean("pref_talkback", false)
}
