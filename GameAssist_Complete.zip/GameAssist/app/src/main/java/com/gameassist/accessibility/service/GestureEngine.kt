package com.gameassist.accessibility.service
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import kotlin.math.hypot

class GestureEngine(private val service: AccessibilityService, private val screenW: Int) {
    private val handler = Handler(Looper.getMainLooper())
    var busy = false; private set
    var currentX = screenW / 2f
    var currentY = 0f

    fun moveTo(targetX: Float, targetY: Float, urgency: Float, speedFraction: Float, minIntervalMs: Long) {
        if (busy || urgency <= 0f) return
        val dx = targetX - currentX; val dy = targetY - currentY
        val dist = hypot(dx, dy)
        if (dist < 8f) return
        val speed = speedFraction * screenW
        val duration = (dist / speed * 1000f).toLong().coerceIn(120, 1200)
        val steps = (duration / 16).toInt().coerceIn(2, 60)
        val path = Path().apply {
            moveTo(currentX, currentY)
            for (i in 1..steps) {
                val t = i / steps.toFloat()
                val e = t * t * (3 - 2 * t)
                lineTo(currentX + dx * e, currentY + dy * e)
            }
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration, false)
        busy = true
        service.dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { busy = false; currentX = targetX; currentY = targetY }
                override fun onCancelled(g: GestureDescription?) { busy = false }
            }, handler)
    }
}
