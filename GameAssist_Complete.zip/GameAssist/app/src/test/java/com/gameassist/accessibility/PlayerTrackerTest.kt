package com.gameassist.accessibility
import com.gameassist.accessibility.service.PlayerTracker
import org.junit.Assert.*
import org.junit.Test

class PlayerTrackerTest {
    @Test fun initialPosition() {
        val t = PlayerTracker(1080, 1920)
        assertEquals(540f, t.x, 1f)
    }
    @Test fun emaSmoothing() {
        val t = PlayerTracker(1080, 1920)
        t.update(1080f, 1632f)
        assertTrue("EMA should be between initial and new", t.x in 540f..1080f)
    }
    @Test fun resetRestoresDefault() {
        val t = PlayerTracker(1080, 1920)
        t.update(100f, 100f); t.reset()
        assertEquals(540f, t.x, 1f)
    }
}
