package com.gameassist.accessibility
import com.gameassist.accessibility.service.ColorDetector
import com.gameassist.accessibility.service.ThreatAnalyzer
import com.gameassist.accessibility.ThreatZone
import com.gameassist.accessibility.Blob
import android.graphics.RectF
import org.junit.Assert.*
import org.junit.Test

class ThreatAnalyzerTest {
    private val W = 1080; private val H = 1920
    private val analyzer = ThreatAnalyzer(W, H)
    private fun blob(zone: ThreatZone, cy: Float) = Blob(zone, when(zone){ThreatZone.LEFT->200f;ThreatZone.RIGHT->880f;else->540f}, cy, RectF(), 20)
    private fun frame(meteors: List<Blob>=emptyList(), ufos: List<Blob>=emptyList(), cols: List<Blob>=emptyList()) = ColorDetector.FrameBlobs(meteors,ufos,cols)

    @Test fun leftThreatMovesRight() {
        val action = analyzer.analyze(540f, frame(meteors=listOf(blob(ThreatZone.LEFT, 1200f))))
        assertTrue("Should move right", action.targetX > 540f)
    }
    @Test fun rightThreatMovesLeft() {
        val action = analyzer.analyze(540f, frame(meteors=listOf(blob(ThreatZone.RIGHT, 1200f))))
        assertTrue("Should move left", action.targetX < 540f)
    }
    @Test fun noThreatStaysIdle() {
        val action = analyzer.analyze(540f, frame())
        assertEquals(0f, action.urgency, 0.01f)
    }
    @Test fun centerThreatMovesToEdge() {
        val action = analyzer.analyze(540f, frame(meteors=listOf(blob(ThreatZone.CENTER, 1200f))))
        assertTrue("Should move away from center", action.targetX != 540f)
    }
}
