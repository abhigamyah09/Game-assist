package com.gameassist.accessibility
import com.gameassist.accessibility.util.ColorUtils
import org.junit.Assert.*
import org.junit.Test
import android.graphics.Color

class ColorUtilsTest {
    @Test fun redIsMeteor() = assertTrue(ColorUtils.isMeteor(Color.RED))
    @Test fun blueIsUFO() = assertTrue(ColorUtils.isUFO(Color.rgb(0,100,220)))
    @Test fun whiteIsCollectible() = assertTrue(ColorUtils.isCollectible(Color.WHITE))
    @Test fun greenIsNone() {
        assertFalse(ColorUtils.isMeteor(Color.GREEN))
        assertFalse(ColorUtils.isUFO(Color.GREEN))
    }
    @Test fun rgbDistanceSameColor() = assertEquals(0.0, ColorUtils.rgbDistance(Color.RED, Color.RED), 0.001)
    @Test fun isCloseTrue() = assertTrue(ColorUtils.isClose(Color.RED, Color.rgb(250,5,5)))
}
