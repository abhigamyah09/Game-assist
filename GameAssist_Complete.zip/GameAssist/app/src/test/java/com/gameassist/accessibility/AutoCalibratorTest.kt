package com.gameassist.accessibility
import com.gameassist.accessibility.service.AutoCalibrator
import org.junit.Assert.*
import org.junit.Test

class AutoCalibratorTest {
    @Test fun notCalibratedInitially() = assertFalse(AutoCalibrator(3).calibrated)
    @Test fun resetWorks() {
        val c = AutoCalibrator(1); repeat(15) { c.feed(android.graphics.Bitmap.createBitmap(1,1,android.graphics.Bitmap.Config.ARGB_8888)) }
        assertTrue(c.calibrated); c.reset(); assertFalse(c.calibrated)
    }
}
