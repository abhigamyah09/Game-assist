# GameAssist ProGuard Rules
-keep class com.gameassist.accessibility.** { *; }
-keepclassmembers class * extends android.accessibilityservice.AccessibilityService { *; }
